import time
import json
import config as cfg
import filemanager as fm
import webapp as wa
import threading
import htmlreport as htmlreport
import uuid
import shutil



test_suite="chatmfc"
fm.loadall(test_suite)


def starttest(name, browser_type, browser_profile, datarow_type, iterations, startnewbrowser, testcasedef):

    drv=wa.webui()
    drv.browser_type=browser_type
    drv.browser_profile=browser_profile
    drv.startnewbrowser=startnewbrowser
    drv.runtestcase(name, testcasedef,iterations, datarow_type )


def runtest():
    threads=[]
    thread_name=""
    i=1
    for testcase_grp in cfg.run_data['testcases'].keys():
        testcases=cfg.run_data['testcases'][testcase_grp]
        for testcase in testcases:
            testcase=cfg.testcase_config.get(testcase, {})

            browser_type = testcase.get("browser", "chrome")
            datarow_type = testcase.get("datarow_type", "*")
            iterations = testcase.get("iterations", "1")
            startnewbrowser=testcase.get("startnewbrowser", True)

            testcasename = testcase.get("name", "")
            #print(f"Starting test case: {testcasename} on browser: {browser_type}")
            browser_profile = []
            testcasedef = cfg.testcase_data[testcasename]
            skiptc=testcasedef.get("skip", False)
            if not skiptc:
                #thread_name=testcasedef.get("name", f"testcase_{i}")
                thread_name=f"user_{i}"
                i+=1
                t=threading.Thread(target=starttest, args=(thread_name, browser_type, browser_profile, datarow_type, iterations, startnewbrowser, testcasedef,))
                threads.append(t)
                t.start()

        for t in threads:
            t.join()

#<div id="initial-loader"><div class="chatmfc-html-spinner"></div><div class="loading-text">Loading ChatMFC...</div></div>
runtest()
htmlreport.htmlreport(cfg.final_test_report)

