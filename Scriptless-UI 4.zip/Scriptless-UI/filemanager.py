import json
import config as cfg

test_suite_name=""
def loador(suite_name):
    try:
        with open(f"./{suite_name}/objectrepository.json", 'r') as f:
            cfg.or_data = json.load(f)
    except:
        pass



def saveor():
    global test_suite_name
    try:
        with open(f"./{test_suite_name}/objectrepository.json", 'w') as f:
            json.dump(cfg.or_data, f, indent=4)
    except Exception as e:
        print(f"Error saving object repository: {e}")


def loadsteps(suite_name):
    try:
        with open(f"./{suite_name}/steps.json", 'r') as f:
            cfg.steps_data = json.load(f)
    except:
        pass

def loadtestcases(suite_name):
    try:
        with open(f"./{suite_name}/testcases.json", 'r') as f:
            cfg.testcase_data = json.load(f)
    except:
        pass

def loadrunfile(suite_name):
    try:
        with open(f"./{suite_name}/run.json", 'r') as f:
            cfg.run_data = json.load(f)
    except:
        pass

def loadtestcaseconfig(suite_name):
    try:
        with open(f"./{suite_name}/config.json", 'r') as f:
            cfg.testcase_config = json.load(f)
    except:
        pass

def loaddatafile(suite_name):
    try:
        with open(f"./{suite_name}/datatable.json", 'r') as f:
            cfg.data_dict = json.load(f)
    except:
        pass

def loadall(suite_name):
    global test_suite_name
    test_suite_name=suite_name
    loador(suite_name)
    loadsteps(suite_name)
    loadtestcases(suite_name)
    loadtestcaseconfig(suite_name)
    loadrunfile(suite_name)
    loaddatafile(suite_name)