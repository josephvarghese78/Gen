from selenium.webdriver.common.keys import Keys
import os

#determine os
if os.name=="nt":
    osName="WIN"
elif os.name=="posix":
    osName="MAC"
else:
    osName=""


#constants
HEAL_THREASHOLD = ['HIGH_MATCH', 'VERY_HIGH_MATCH']
FALLBACK_HEAL_THREASHOLD = ['POSSIBLE_MATCH', 'MATCH', 'HIGH_MATCH', 'VERY_HIGH_MATCH']
UPDATE_OBJREPO_ON_HEAL = True
UPDATE_OBJREPO_ON_NEW_DESC_FOUND = True
ELEMENT_HIGHLIGHT_COLOR="blue"
ELEMENT_HIGHLIGHT_SIZE=4
ELEMENT_HIGHLIGHT_BLINK=1
DEFAULT_OBJINDEX=-1

#os key mapping
KEY_MAP = {
    "ctrl": Keys.CONTROL,
    "cmd": Keys.COMMAND,
    "control": Keys.CONTROL,
    "shift": Keys.SHIFT,
    "alt": Keys.ALT,
    "enter": Keys.ENTER,
    "return": Keys.RETURN,
    "tab": Keys.TAB,
    "space": Keys.SPACE,
    "backspace": Keys.BACKSPACE,
    "delete": Keys.DELETE,
    "del": Keys.DELETE,
    "esc": Keys.ESCAPE,
    "escape": Keys.ESCAPE,
    "home": Keys.HOME,
    "end": Keys.END,
    "insert": Keys.INSERT,
    "ins": Keys.INSERT,
    "page_up": Keys.PAGE_UP,
    "pgup": Keys.PAGE_UP,
    "page_down": Keys.PAGE_DOWN,
    "pgdn": Keys.PAGE_DOWN,
    "arrow_up": Keys.ARROW_UP,
    "up": Keys.ARROW_UP,
    "arrow_down": Keys.ARROW_DOWN,
    "down": Keys.ARROW_DOWN,
    "arrow_left": Keys.ARROW_LEFT,
    "left": Keys.ARROW_LEFT,
    "arrow_right": Keys.ARROW_RIGHT,
    "right": Keys.ARROW_RIGHT,
    "f1": Keys.F1,
    "f2": Keys.F2,
    "f3": Keys.F3,
    "f4": Keys.F4,
    "f5": Keys.F5,
    "f6": Keys.F6,
    "f7": Keys.F7,
    "f8": Keys.F8,
    "f9": Keys.F9,
    "f10": Keys.F10,
    "f11": Keys.F11,
    "f12": Keys.F12,
    # Add more special keys if needed
}


sv_ema=[]
#shared variables
osName=None
or_data=None
steps_data=None
run_data=None
data_dict=None
testScript=None
testcase_data=None
testcase_config=None
final_test_report = []
tc_duration=0


#common functions
def getScoreType(score):
    if score <= 0.3:
        return "NO_MATCH"
    elif score > 0.30 and score <= 0.5:
        return "LOW_MATCH"
    elif score > 0.5 and score <=0.65:
        return "POSSIBLE_MATCH"
    elif score >= 0.65 and score <=0.85:
        return "MATCH"
    elif score>0.85 and score<=1.0:
        return "HIGH_MATCH"
    else:
        return "VERY_HIGH_MATCH"