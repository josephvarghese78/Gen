import json
import random
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options as chrome_options
from selenium.webdriver.edge.options import Options as edge_options
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.ui import Select
import os
import copy
import selfheal as shealEngine
#
driver = webdriver.Chrome()

def highlight(element):
    try:
        org_style = element.get_attribute("style")
        for _ in range(5):
            driver.execute_script("arguments[0].style.border='20px solid blue'", element)
            time.sleep(.5)
            driver.execute_script("arguments[0].style.border='none'", element)
            time.sleep(.5)
        driver.execute_script("arguments[0].setAttribute('style', arguments[1])", element, org_style)
    except:
        pass

"""
                    if index == -1:
                        index = len(obj) - 1
                        element = obj[-1]
                    elif len(obj) == 1:
                        element = obj[0]
                    elif len(obj) > 0 and index >= 0 and index < len(obj):
                        element = obj[index]
                    else:
                        element = obj[-1]
"""
def filter_element1(elements, index):
    elements = [element for element in elements if element.is_displayed() and element.is_enabled()]

    if len(elements) == 1:
        return elements[0], 1
    else:
        #elements1 = [element for element in elements if element.is_displayed() and element.is_enabled()]
        if len(elements) == 0:
            return None, 2
        elif len(elements) == 1:
            return elements[0], 3
        elif index >= 0 and index < len(elements):
            return elements[index], 4
        else:
            return elements[-1], 5

def filter_element(oldElement, elements, index):
    valid_elements1 = []
    valid_elements = [element for element in elements if element.is_displayed() and element.is_enabled()]

    if len(valid_elements) == 0:
        print("option-1")
        return None
    elif len(valid_elements) == 1:
        print("option-2")
        return valid_elements[0]
    else:
        print("option-3")
        for element in valid_elements:
            tmp_oldElement=copy.deepcopy(oldElement)
            del tmp_oldElement["parent"]
            del tmp_oldElement["pre_sibling"]
            del tmp_oldElement["fol_sibling"]
            sh = shealEngine.self_heal()
            element_desc=sh.getAttributes(element, driver)
            if element_desc==tmp_oldElement:
                valid_elements1.append(element)

        valid_elements=valid_elements1

        if len(valid_elements) == 1:
            print("option-4")
            return valid_elements[0]
        elif len(valid_elements)>1 and index >= 0 and index < len(valid_elements):
            print("option-5")
            return valid_elements[index]
        elif len(valid_elements)>1:
            print("option-6")
            return valid_elements[-1]
        else:
            print("option-7")
            return None


oe=   {
    "style": "",
    "innertext": "JV\nSettings",
    "attrs": {
        "class": "relative group bg-navyNeutral-400 dark:bg-white text-white dark:text-navyNeutral-800 w-8 h-8 rounded-full flex items-center justify-center select-none",
        "id": "user-profile-btn",
        "tag": "div"
    }
}
sh = shealEngine.self_heal()
driver.get("https://chatmfc-np.manulife.com/")
input("pass1")


e1=driver.find_elements(By.ID, "mode-dropdown-btn")

highlight(e1[0])
e1[0].click()









input("exit")
#buttonWrapper buttonAccept