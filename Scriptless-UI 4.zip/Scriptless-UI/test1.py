a={
        "innertext": "Themes",
        "attrs": {
            "class": "font-ManulifeRegular leading-6 text-base dark:text-white text-navyNeutral-800",
            "tag": "div",
            "index1": 0
        }
}
b={
    "innertext": "Themes",
    "attrs": {
        "class": "font-ManulifeRegular leading-6 text-base dark:text-white text-navyNeutral-800",
        "tag": "div"
    }
}
#if "index" in a["attrs"].keys() :
#    del a["attrs"]["index"]
try:
    del a["attrs"]["index"]
except:
    pass
print (a==b)
