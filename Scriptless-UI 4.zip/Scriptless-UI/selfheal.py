import difflib
import time

from selenium.webdriver.common.by import By
import config as cfg
import json
import threading
import uuid


class self_heal:

    def __init__(self):
        self.selenium_keys = ['id', 'name', 'class_name', 'css_selector', 'for', 'class', 'tag', 'type', 'xpath']
        self.thread_name = ""

    def getAttributes(self, e, d):

        try:
            if e is None:
                return None
            attributes = d.execute_script("""
                var items = {}; 
                for (index = 0; index < arguments[0].attributes.length; ++index) {
                     items[arguments[0].attributes[index].name] = arguments[0].attributes[index].value
                }; 
                return items;
           """, e)

            selenium_attrs = {}
            other_attrs = {}
            for k, v in attributes.items():
                if k in self.selenium_keys or k.startswith("data-") or k.startswith("aria-"):
                    selenium_attrs[k] = v
                else:
                    other_attrs[k] = v

            t = e.get_attribute("value")
            if t is not None:
                other_attrs['text'] = t
            t = e.get_attribute('innerText')
            if t is not None:
                other_attrs['innertext'] = t

            other_attrs['attrs'] = selenium_attrs
            other_attrs['attrs']['tag'] = e.tag_name

            return other_attrs
        except Exception as ex:
            print(f"Exception in getAttributes: {ex}")
            return None

    def tag_similarity(self, oldElement, newElement):
        old_tag = oldElement.get("tag", "").lower()
        old_type = oldElement['attrs'].get("type", "").lower()

        if old_tag == 'input' and old_type == '':
            old_type = 'text'
        new_tag = newElement.get("tag", "").lower()
        new_type = newElement['attrs'].get("type", "").lower()

        if new_tag == 'input' and new_type == '':
            new_type = 'text'
        # text controls
        if old_tag == 'input' and old_type == 'text' and new_tag == 'textarea':
            return True
        if old_tag == 'textarea' and new_tag == 'input' and new_type == 'text':
            return True

        # button
        if old_tag in ['input', 'button'] and old_type in ['submit', 'button'] and new_tag in ['a', 'button',
                                                                                               'img'] and new_type in [
            'submit', 'button', '']:
            return True
        if new_tag in ['input', 'button'] and new_type in ['submit', 'button'] and old_tag in ['a', 'button',
                                                                                               'img'] and old_type in [
            'submit', 'button', '']:
            return True

        # link & image
        if old_tag in ['a', 'img'] and new_tag in ['a', 'img', 'button'] and new_type in ['submit', 'button', '']:
            return True
        if new_tag in ['a', 'img'] and old_tag in ['a', 'img', 'button'] and old_type in ['submit', 'button', '']:
            return True
        return False

    def compare_element_texts(self, oldElement, newElement):
        text1 = oldElement.get('text', '') or oldElement.get('innertext', '')
        text2 = newElement.get('text', '') or newElement.get('innertext', '')
        similarity = difflib.SequenceMatcher(None, str(text1).strip(), str(text2).strip()).ratio() * .10
        return similarity

    def getElementScore(self, failedElement, newElement, mainelement=True):
        score = 0
        tag_score = 0
        key_attrscore = 0
        nonkey_attrscore = 0
        text_score = 0

        mx_keyattr = 0
        mx_nonkeyattr = 0
        keyattr_count = 0
        nonkeyattr_count = 0

        for attributeKey in failedElement['attrs'].keys():
            if attributeKey.lower() != "xpath":
                if attributeKey.lower() in ['id', 'name', 'class_name', 'css_selector', 'for', 'class']:
                    mx_keyattr += 1
                else:
                    mx_nonkeyattr += 1

        # maxAttrs = len(list(failedElement['attrs'].keys()))
        # if 'xpath' in failedElement['attrs'].keys():
        #   maxAttrs -= 1
        maxAttrs = mx_keyattr + mx_nonkeyattr

        try:
            if failedElement.get("tag", "") == newElement.get("tag", ""):
                tag_score = .15
            elif self.tag_similarity(failedElement, newElement):
                tag_score = .1
        except:
            pass

        print("tag match", tag_score)

        try:
            if maxAttrs > 0:
                for attributeKey in failedElement['attrs'].keys():
                    if attributeKey.lower() != 'xpath':
                        oldElementAttr = failedElement['attrs'].get(attributeKey, "")
                        newElementAttr = newElement['attrs'].get(attributeKey, "")

                        if attributeKey.lower() in ['id', 'name', 'class_name', 'css_selector', 'for', 'class']:
                            key_attrscore += (difflib.SequenceMatcher(None, oldElementAttr, newElementAttr).ratio() * (
                                    .75 / mx_keyattr))
                            keyattr_count += 1
                        else:
                            nonkey_attrscore += (
                                        difflib.SequenceMatcher(None, oldElementAttr, newElementAttr).ratio() * (
                                        .25 / mx_nonkeyattr))
                            nonkeyattr_count += 1

            if mx_keyattr == keyattr_count and keyattr_count == 0:
                key_attrscore = .75

            if mx_nonkeyattr == nonkeyattr_count and nonkeyattr_count == 0:
                nonkey_attrscore = .25


        except:
            pass

        if mainelement:
            if key_attrscore >= .75:
                key_attrscore += .1

        print("attr match", key_attrscore, nonkey_attrscore)
        # text score
        try:
            text_score = self.compare_element_texts(failedElement, newElement)
        except:
            pass

        print("txt match", text_score)

        score = (tag_score + key_attrscore + nonkey_attrscore + text_score)

        print("final element score", score)

        return tag_score, key_attrscore, nonkey_attrscore, text_score, score

    def check_element_exists_in_or(self, newElement):
        try:
            for key in cfg.or_data.keys():
                old_attrs = cfg.or_data[key]['attrs'].copy()  # avoid modifying original
                old_attrs["xpath"] = ""
                new_attrs = newElement['attrs'].copy()
                new_attrs["xpath"] = ""

                if old_attrs == new_attrs and \
                        cfg.or_data[key]['text'] == newElement['text'] and \
                        cfg.or_data[key]['innertext'] == newElement['innertext'] and \
                        cfg.or_data[key]['tag'] == newElement['tag']:
                    return True  # found a match
            return False  # no match found after checking all elements
        except Exception as e:
            print(f"Exception in check_element_exists_in_or: {e}")
            return False

    def selfHealEngine(self, failedElement, d):

        best_match = None
        best_score = 0
        best_attrs = None
        scoreType = None
        best_key_attr_score = 0
        best_self_score = 0
        best_context_score = 0
        element_scores = []

        try:
            elements = d.find_elements(By.XPATH, ".//*")  # old was d.find_elements(By.XPATH, "//*")
            svelm = []
            for element in elements:

                score = 0
                selfScore = 0
                parentScore = 0
                preSiblingScore = 0
                folSiblingScore = 0
                contextScore = 0
                tag_score = 0
                key_attrscore = 0
                nonkey_attrscore = 0
                text_score = 0

                attributes = self.getAttributes(element, d)

                # em=check_element_exists_in_or(attributes)
                em = False
                if not em:
                    print('old element 1', failedElement)
                    print('new element 1', attributes)

                    print("element score calculation started...")
                    try:
                        tag_score, key_attrscore, nonkey_attrscore, text_score, selfScore = self.getElementScore(
                            failedElement, attributes, True)
                    except Exception as e:
                        print(f"Exception in selfHealEngine while calculating selfScore: {e}")
                        selfScore = 0

                    print('Self Score:', selfScore)
                    print("parent score calculation started...")

                    try:
                        parent_attributes = self.getAttributes(element.find_element(By.XPATH, ".."), d)
                        _, _, _, _, parentScore = self.getElementScore(failedElement['parent'], parent_attributes,
                                                                       False)
                        parentScore = parentScore * .40
                    except Exception as e:
                        try:
                            if "no such element" in str(e) and failedElement['parent'] is None:
                                parentScore = .40
                        except Exception as e:
                            parentScore = .40

                    print('Parent Score:', parentScore)

                    print("pre_sibling score calculation started...")

                    try:
                        preSibling_attributes = self.getAttributes(
                            element.find_element(By.XPATH, "preceding-sibling::*[1]"), d)
                        _, _, _, _, preSiblingScore = self.getElementScore(failedElement['pre_sibling'],
                                                                           preSibling_attributes, False)
                        preSiblingScore = preSiblingScore * .25
                    except Exception as e:
                        try:
                            if "no such element" in str(e) and failedElement['pre_sibling'] is None:
                                preSiblingScore = .25
                        except Exception as e:
                            preSiblingScore = .25

                    print('Pre Sibling Score:', preSiblingScore)

                    print("fol_sibling score calculation started...")

                    try:
                        folSibling_attributes = self.getAttributes(
                            element.find_element(By.XPATH, "following-sibling::*[1]"), d)
                        _, _, _, _, folSiblingScore = self.getElementScore(failedElement['fol_sibling'],
                                                                           folSibling_attributes, False)
                        folSiblingScore = folSiblingScore * .15
                    except Exception as e:
                        try:
                            if "no such element" in str(e) and failedElement['fol_sibling'] is None:
                                folSiblingScore = .15
                        except Exception as e:
                            folSiblingScore = .15

                    print('fol Sibling Score:', folSiblingScore)

                    contextScore = (parentScore + preSiblingScore + folSiblingScore)

                    if contextScore >= .8:
                        contextScore += .15
                    print('Context Score:', contextScore)

                    score = selfScore + contextScore
                    print('Total Score:', score)

                    selfscoretype = cfg.getScoreType(selfScore)
                    key_scoreType = cfg.getScoreType(key_attrscore)
                    contextScoreType = cfg.getScoreType(contextScore)

                    print('bests...before')
                    print('best_score', best_score)
                    print('best_key_attr_score', best_key_attr_score)
                    print('best_self_score', best_self_score)
                    print('best_context_score', best_context_score)

                    if selfscoretype in cfg.HEAL_THREASHOLD or key_scoreType in cfg.HEAL_THREASHOLD:
                        if selfScore > best_self_score:
                            print("update 1...")
                            best_self_score = selfScore
                            best_key_attr_score = key_attrscore
                            best_score = score
                            best_match = element
                            best_attrs = attributes
                            best_context_score = contextScore
                            scoreType = cfg.getScoreType(best_score)
                            element_scores.append({
                                "update_mode": 1,
                                "best_self_score": selfScore,
                                "best_key_attr_score": key_attrscore,
                                "best_score": score,
                                "best_match": element,
                                "best_attrs": attributes,
                                "best_context_score": contextScore,
                                "scoreType": scoreType})
                        elif key_attrscore > best_key_attr_score and contextScore >= best_context_score and contextScore >= .8:
                            print("update 2...")
                            best_self_score = selfScore
                            best_key_attr_score = key_attrscore
                            best_score = score
                            best_match = element
                            best_attrs = attributes
                            best_context_score = contextScore
                            scoreType = cfg.getScoreType(best_score)
                            element_scores.append({
                                "update_mode": 2,
                                "best_self_score": selfScore,
                                "best_key_attr_score": key_attrscore,
                                "best_score": score,
                                "best_match": element,
                                "best_attrs": attributes,
                                "best_context_score": contextScore,
                                "scoreType": scoreType})
                    elif contextScore >= .95:  # and contextScore>=best_context_score:
                        if selfscoretype in cfg.FALLBACK_HEAL_THREASHOLD or key_scoreType in cfg.FALLBACK_HEAL_THREASHOLD or contextScore >= best_context_score:
                            print("update 3...")
                            best_self_score = selfScore
                            best_key_attr_score = key_attrscore
                            best_score = score
                            best_match = element
                            best_attrs = attributes
                            best_context_score = contextScore
                            scoreType = cfg.getScoreType(best_score)
                            element_scores.append({
                                "update_mode": 3,
                                "best_self_score": selfScore,
                                "best_key_attr_score": key_attrscore,
                                "best_score": score,
                                "best_match": element,
                                "best_attrs": attributes,
                                "best_context_score": contextScore,
                                "scoreType": scoreType})

                    print('bests...after')
                    print('best_score', best_score)
                    print('best_key_attr_score', best_key_attr_score)
                    print('best_self_score', best_self_score)
                    print('best_context_score', best_context_score)

            # print(element_scores)
            print("********************************************************")
            print(element_scores)

            if len(element_scores) > 1:
                best_score, best_match, best_attrs, scoreType = choose_best_element(element_scores)
                print('final:', best_score, best_attrs, scoreType)
                print("********************************************************")

                return best_score, best_match, best_attrs, scoreType
            else:
                print("********************************************************")
                print('final:', best_score, best_attrs, scoreType)
                print("********************************************************")

                return best_score, best_match, best_attrs, scoreType


        except Exception as e:
            print(f"Exception in selfHealEngine: {e}")
            if best_match is not None:
                try:
                    if len(element_scores) > 1:
                        best_score, best_match, best_attrs, scoreType = choose_best_element(element_scores)
                        return best_score, best_match, best_attrs, scoreType
                    else:
                        return best_score, best_match, best_attrs, scoreType
                except Exception as e:
                    return 0, None, None, None
            else:
                return 0, None, None, None

def choose_best_element(element_scores):
    best_element = sorted(
        element_scores,
        key=lambda x: (
            x["update_mode"],  # min
            -x["best_score"],  # max
            -x["best_self_score"],  # max
            -x["best_key_attr_score"],  # max
            -x["best_context_score"]  # max
        )
    )[0]
    best_score = best_element['best_score']
    best_match = best_element['best_match']
    best_attrs = best_element['best_attrs']
    scoreType = cfg.getScoreType(best_element['best_score'])
    print('final:', best_score, best_attrs, scoreType)
    print("********************************************************")

    return best_score, best_match, best_attrs, scoreType