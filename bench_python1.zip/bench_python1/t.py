a={
            "innertext": "Name:",
            "attrs": {
                "class": "form-row",
                "tag": "div"
            }
        }


b={

            "attrs": {
                "tag": "div",
                "class": "form-row",

            },
        "innertext": "Name:",
        }

del a["innertext"]
print(a)

print(a==b)