project_name="BENCH_TEST"
valid_status_codes=[200,201,204]
ignore_status_codes=[429,499]
error_threshold=5
users=1
runfor=20
user_step=5
think_time=[3,4,5,6,7]
rampup_per_user=[2,3,1]
delay_between_thread=1
stop_at_user=2
stop_requested=False


error_flags=['F']  # P=Pass, F=Fail, W=

#active_threads=0
samples_started=0
samples_completed=0
total_response_time=0
avg=0
el=0

requests_data=None
db_conn=None
db_filename=""
db_cursor=None

suite_id=""
test_name=""
test_start_time=None
error_percent=0
running_users=0
current_errors=0

standard_sla = {
  "avg": 1.56,
  "percentile_10": 0.5,
  "percentile_20": 0.6,
  "percentile_30": 0.7,
  "percentile_40": 0.8,
  "percentile_50": 0.9,
  "percentile_60": 1.0,
  "percentile_70": 1.2,
  "percentile_80": 1.5,
  "percentile_90": 2.0,
  "percentile_95": 3.0,
  "percentile_99": 5.0
}

project_sla={
  "avg": 1.56,
  "percentile_10": 0.5,
  "percentile_20": 0.6,
  "percentile_30": 0.7,
  "percentile_40": 0.8,
  "percentile_50": 0.9,
  "percentile_60": 1.0,
  "percentile_70": 1.2,
  "percentile_80": 1.5,
  "percentile_90": 2.0,
  "percentile_95": 3.0,
  "percentile_99": 5.0
}



