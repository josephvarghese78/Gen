import random
import time
import requests
from datetime import datetime
import time
import config as cfg
import json
import uuid
from decorators import task
from requests.models import Response
from harlib import har

class api_requests:

    @task(name='ttddssrr', weight=2, enabled=False)
    def tdsr(self, user_session):
        resp= user_session.get("http://nl:3200/expense/tdsr", timeout=10000, verify=True)

        return resp,  self.tdsr.test_name

    @task(name='xyx', weight=2, type='har')
    def tdsr1(self, user_session, tname, i):
        h=har()

        error_flags=h.run(tname,"tdsr", user_session, d, i)
        return error_flags