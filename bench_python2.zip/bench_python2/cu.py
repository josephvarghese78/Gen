import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages
import seaborn as sns
from datetime import datetime
import os
import glob
import numpy as np
#from pyodbc import connect
import config as cfg
from reportlab.lib import pagesizes, colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch

conn = sqlite3.connect("./db/sample_1.db")

def detect_saturation(
        threads,
        avg_latency,
        latency_threshold=0.10,  # 10% latency growth allowed between steps
        efficiency_drop_threshold=0.10,  # 10% efficiency drop allowed
        throughput_flat_threshold=0.05,  # 5% throughput gain considered flat
        max_latency_sla=1.0  # absolute SLA threshold in seconds
):

    sum_of_threads=np.sum(threads)
    min_thread=np.min(threads)
    max_thread=np.max(threads)

    threads = np.array(threads, dtype=float)
    avg_latency = np.array(avg_latency, dtype=float)

    # Metrics
    throughput = threads / avg_latency
    efficiency = throughput / threads  # per-user throughput

    # Derivatives
    throughput_gain_pct = np.diff(throughput) / throughput[:-1]
    latency_growth = np.diff(avg_latency) / avg_latency[:-1]
    efficiency_drop = -np.diff(efficiency) / efficiency[:-1]

    safe_index = 0
    saturation_index = None
    notes = []
    test_score=[]
    test_score_data={}

    for i in range(0, len(threads)):
        test_score_data={}
        test_score_data["users"] = str(int(threads[i]))
        test_score_data["latency_sla"]=0
        test_score_data["throughput_stablity"]=0
        test_score_data["latency_stability"]=0
        test_score_data["efficiency_drop"]=0

        load_factor=(threads[i]-min_thread)/(max_thread-min_thread)
        inverse_load = 1 - load_factor
        risk_factor = 1 + (1.3 * inverse_load) + (0.7 * load_factor)

        # Check absolute SLA
        sla_violation = avg_latency[i] > max_latency_sla
        if sla_violation:
            saturation_index = i
            test_score_data["latency_sla"] = 40 * risk_factor
            notes.append(f"Latency {avg_latency[i]:.3f}s exceeds SLA {max_latency_sla}s")
            #break

        # Healthy scaling check
        tp_health = throughput_gain_pct[i - 1] > throughput_flat_threshold
        lt_health= latency_growth[i - 1] < latency_threshold
        ef_health= efficiency_drop[i - 1] < efficiency_drop_threshold
        healthy=(tp_health and lt_health and ef_health)

        if healthy:
            safe_index = i
        else:
            saturation_index = i
            if not tp_health:
                test_score_data["throughput_stablity"] = 25 * (1 + 0.7 * (risk_factor - 1))
                notes.append(f"Throughput flattening reducing overtime, this indicates system is failing to scale or not getting response in time, found in {i} user test.")

            if not lt_health:
                test_score_data["latency_stability"] = 25 * (1 + 0.5 * (risk_factor - 1))
                notes.append(f"Lattency is increasing, this indicates when load increases response time delays, found in {i} user test.")

            if not ef_health:
                test_score_data["efficiency_drop"] = 10 * 1
                notes.append(f"Efficiency drops >10% when user load increases, found in {i} user test.")
            break
        test_score_data["weighted_score"]=100-(test_score_data["latency_sla"]+
                                                            test_score_data["throughput_stablity"]+
                                                            test_score_data["latency_stability"]+
                                                            test_score_data["efficiency_drop"])

        if test_score_data["weighted_score"]>=90 and test_score_data["weighted_score"]<=100:
            test_score_data["grade"]="Excellent"
        elif test_score_data["weighted_score"]>=80 and test_score_data["weighted_score"]<=89:
            test_score_data["grade"]="Very Good"
        elif test_score_data["weighted_score"]>=70 and test_score_data["weighted_score"]<=79:
            test_score_data["grade"]="Good"
        elif test_score_data["weighted_score"]>=60 and test_score_data["weighted_score"]<=69:
            test_score_data["grade"]="Fair"
        elif test_score_data["weighted_score"]>=50 and test_score_data["weighted_score"]<=59:
            test_score_data["grade"]="Poor"
        else:
            test_score_data["grade"]="Fail"

        test_score.append(test_score_data)

    state = "SCALING (No saturation detected)" if saturation_index is None else "SATURATION DETECTED"

    return {
        "safe_users": int(threads[safe_index]),
        "safe_throughput": float(throughput[safe_index]),
        "saturation_users": int(threads[saturation_index]) if saturation_index is not None else None,
        "state": state,
        "throughput": throughput,
        "efficiency": efficiency,
        "avg_latency":avg_latency,
        "notes": notes,
        "threads": threads,
        "test_score": test_score
    }

def latency_data():
    """Fetch performance test data from SQLite into a pandas DataFrame"""
    #conn = sqlite3.connect(db_path)
    global conn

    query="""
    WITH ordered AS (
    SELECT suite_name, test_name, response_time/1000 as response_time, max_threads,
           ROW_NUMBER() OVER (PARTITION BY suite_name, test_name ORDER BY response_time/1000) AS rn,
           COUNT(*) OVER (PARTITION BY suite_name, test_name) AS cnt
        FROM performance
    )
    SELECT suite_name, max_threads, test_name,
           MIN(response_time) AS min,
           MAX(response_time) AS max,
           AVG(response_time) AS avg,
           max_threads/AVG(response_time) as throughput,
           (max_threads/AVG(response_time))/max_threads as efficiency,
           (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = (cnt + 1)/2) AS median_response_time,
            (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.1 * cnt AS INT)) AS percentile_10,
            (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.2 * cnt AS INT)) AS percentile_20,
            (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.3 * cnt AS INT)) AS percentile_30,
            (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.4 * cnt AS INT)) AS percentile_40,
            (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.5 * cnt AS INT)) AS percentile_50,
            (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.6 * cnt AS INT)) AS percentile_60,
            (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.7 * cnt AS INT)) AS percentile_70,
            (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.8 * cnt AS INT)) AS percentile_80,
           (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.9 * cnt AS INT)) AS percentile_90,
           (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.95 * cnt AS INT)) AS percentile_95,
           (SELECT response_time FROM ordered o2 
            WHERE o2.suite_name = o1.suite_name AND o2.test_name = o1.test_name AND rn = CAST(0.99 * cnt AS INT)) AS percentile_99
    FROM ordered o1
    GROUP BY suite_name, max_threads, test_name
    order by max_threads 
    """
    df = pd.read_sql_query(query, conn)
    return df

df_latency = latency_data()

threads=[]
avg_lat=[]
p90=[]
p95=[]
p99=[]
for _, row in df_latency.iterrows():
    threads.append(row["max_threads"])
    avg_lat.append(row["avg"])
    p90.append(row["percentile_90"])
    p95.append(row["percentile_95"])
    p99.append(row["percentile_99"])




result=detect_saturation(threads, avg_lat)

print(result)