import httpx
import json

headers={
    "accept": "application/json, text/plain, */*",
    "Authorization": "Bearer eyJhbGciOiJIUzI1Ni"
}
resp=httpx.request("get", url="http://nl:3200/expense/tdsr", headers=headers, timeout=10000, verify=False)

req=resp
for name in dir(req):
    if not name.startswith("_"):
        try:
            print(f"{name}: {getattr(req, name)}")
        except Exception as e:
            print(f"{name}: <{e}>")

print(json.dumps(resp.json(), indent=4))