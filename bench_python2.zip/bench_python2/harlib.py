import json
import httpx
import time
import random
from datetime import datetime
import sqlite3
import config as cfg

class har:
    def __init__(self):
        self.custom_headers = None
        self.exclude_urls=[]

    def log_performance(self, test_name,
                        thread_name, iteration, start_time, end_time,
                        samples_started, samples_completed, active_threads, think_time,
                        response_time, error_status, error_percent, response_status_code, response):
        db_conn = sqlite3.connect(f"./db/{cfg.db_filename}")
        db_cursor = db_conn.cursor()

        db_cursor.execute("""
                INSERT INTO performance (suite_name,
                test_name, max_threads, thread_name, iteration, start_time,
                end_time, samples_started, samples_completed, active_threads,
                think_time, response_time, error_status, error_percent, response_status_code,
                response ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?,?,?,?,?)
                """,
                          (cfg.suite_id, test_name, cfg.users, thread_name, iteration, start_time, end_time,
                           samples_started, samples_completed, active_threads,
                           think_time, response_time, error_status, error_percent, response_status_code, response))

        db_conn.commit()
        db_conn.close()

    def run(self, threadname, pagename, session, data, i):
        error_flags = []
        resp_codes = []
        objects=data.get("log", {}).get("entries",[1])

        for obj in objects:
            tt = random.choice(cfg.think_time)
            reqobj=obj.get("request", {})
            url = reqobj.get("url", "")
            if not url.endswith(tuple(self.exclude_urls)):
                respheaders=obj.get("response", {}).get("headers", {})
                content_type=next((header["value"] for header in respheaders if header.get("name", "").lower() == "content-type"), "")
                reqheader={}
                method=reqobj.get("method", "")
                headers=reqobj.get("headers", [])
                for header in headers:
                    if not header.get("name", "").startswith(":"):
                        reqheader[header.get("name", "")]=header.get("value", "")


                time.sleep(tt)
                start_time = datetime.now()
                start_time_pc = time.perf_counter()
                #resp, resp_code, start_time, end_time, response_time=self.getresponse(url, method, reqheader)

                if self.custom_headers:
                    reqheader.update(self.custom_headers)

                if method == "GET":
                    resp = session.get(url=url, headers=headers)
                elif method == "POST":
                    resp = session.post(url=url, headers=headers)
                elif method == "PUT":
                    resp = session.put(url=url, headers=headers)
                elif method == "DELETE":
                    resp = session.delete(url=url, headers=headers)
                elif method == "OPTIONS":
                    resp = session.options(f'{url}', headers=headers)
                else:
                    resp = None

                if resp:
                    resp_code = resp.status_code
                else:
                    resp_code=0
                resp_codes.append(resp_code)

                end_time = datetime.now()
                end_time_pc = time.perf_counter()
                response_time = (end_time_pc - start_time_pc) * 1000
                #print("Response:", resp.text)

                error_flag = ""
                if resp_code in cfg.valid_status_codes:
                    error_flag = "P"
                elif resp_code in cfg.ignore_status_codes:
                    error_flag = "W"
                else:
                    error_flag = "F"
                error_flags.append(error_flag)

                self.log_performance(pagename, threadname, i,
                                start_time.strftime("%Y-%m-%d %H:%M:%S.%f"),
                                end_time.strftime("%Y-%m-%d %H:%M:%S.%f"),
                                cfg.samples_started,
                                cfg.samples_completed,
                                cfg.running_users,
                                tt * 1000,
                                response_time,
                                error_flag,
                                cfg.error_percent,
                                resp_code,
                                str(resp.text))


        return error_flags




#f=process_har("")
#print(f)