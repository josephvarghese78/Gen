import json

import requests
import Settings
import PBITokenManager as pbi
from jsonpath_ng import jsonpath, parse

def __getresponse(payload):
    try:
        return requests.post(Settings.api_url, data=payload,
                                     headers=Settings.header,
                                     verify=(Settings.ignoressl),
                                     timeout=Settings.timeout).json()
    except Exception as e:
        #print(e)
        return None

def getresponse(payload):

    while(True):
        api_response = __getresponse(json.dumps(payload))
        #print(api_response)
        if "code" in api_response:
            print("code found")
            pbi.gettoken()
        elif api_response is None:
            print("none found")
            pbi.gettoken()
        else:
            break

    return api_response

def validateresponse(response, jpaths):
    ret=False
    for jpath in jpaths:
        json_expr = parse(jpath)
        v= [match.value for match in json_expr.find(response)][0]
        if v is None:
            ret=False
            break
        else:
            print(v)
            ret=True
    return ret