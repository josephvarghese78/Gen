import csv
import os
import InOfficePresenceMTH as m
import InOfficePresenceYTD as y
import Past3Months as p
import EligibleColleagues as c
import requests
import Settings
import json
import PBITokenManager as pbi
import MiddleRibbon as mr
import IndividualYTD as iytd
import IndividualMTH as imth
import OrgYTDDetails as odet
import IndividualYTDDetails as idet
import InOfficePresenceLM as lm
import Settings as s

run_file_name=""
brkflg=False
while True:
    print("1. Run 'sample.csv'")
    print("2. Run 'emp_list.csv'")
    print("3. custom csv file")
    print("4. Exit")
    ch=input("enter choice: ")
    if ch=="1":
        run_file_name="sample.csv"
        break
    elif ch=="2":
        run_file_name = "emp_list.csv"
        break
    elif ch=="3":
        while True:
            run_file_name=input("type in the csv file name: ")
            if run_file_name[-4:]==".csv" and os.path.exists(f"./{run_file_name}"):
                brkflg=True
                break;
            else:
                print("file dont exist or invalid")
        if brkflg:
            break
    elif ch=="4":
        exit(0)
    else:
        os.system('cls' if os.name=='nt' else 'clear')


#print(pyload)
#Settings.api_url ="https://b7985dfca3af44288ceb05c5b23ed80c.pbidedicated.windows.net/webapi/capacities/B7985DFC-A3AF-4428-8CEB-05C5B23ED80C/workloads/QES/QueryExecutionService/automatic/public/query"
Settings.pbi_url ="https://app.powerbi.com/groups/a2874ef4-74e4-4c27-8a48-eafd919a8500/reports/aa42bd61-3aaa-476c-a9ab-dd53fe23ff79/ReportSection?experience=power-bi"
Settings.ignoressl = False
Settings.timeout = 10000
pbi.gettoken()

def write_csv(file, data):
    #print(data)
    with open(f'./{file}.csv', 'a', encoding='utf-8-sig', newline="") as f:
        writer = csv.writer(f)
        writer.writerow(data)

write_csv("pbi_data", ['id', 'name', 'Level', s.last3monthnames[0], s.last3monthnames[1],
                       s.last3monthnames[2], 'YTD', 'my_eligible_collegues',
                       s.last3monthnames[0], s.last3monthnames[1],
                       s.last3monthnames[2], 'YTD', 'PM1', 'PM2', 'PM3'])
write_csv("pbi_mr_data", ['id', 'name', 'dr_id', 'dr_name', 'comp%', 'colleagues', 'color'])
write_csv("pbi_org_data", ['mgr.id', 'mgr.name', 'name', 'month', 'day', 'date', 'status'])
write_csv("pbi_ind_data", ['id', 'name', 'month', 'day', 'date', 'status'])

with open(f"./{run_file_name}", "r", encoding="utf-8-sig") as csvfile:
    lines= csv.reader(csvfile,skipinitialspace=True)

    #l1 data
    #myresponse = p.get_response(-1, 'Manager_Level_01', 'Gori, Roy')
    #l1_pm1 = myresponse[0]
    #l1_pm2 = myresponse[1]
    #l1_pm3 = myresponse[2]
    #l1_tec = c.get_response(-1, 'Manager_Level_01', 'Gori, Roy')
    #l1_ytd =  y.get_response(-1, 'Manager_Level_01', 'Gori, Roy')
    #l1_lmpresence = lm.get_response(-1, 'Manager_Level_01', 'Gori, Roy')

    for line in lines:
        if line[0].strip()!="id":


            # emp info
            data=[]
            e_id=line[0]
            e_name=line[1]
            e_level=line[2]
            e_managers=line[3].split("|")
            #print(e_id, e_name, e_level, e_managers)
            print(e_name, "...")


            data.append(e_id) #id
            data.append(e_name) #name
            data.append(e_level) #level

            #monthly data (ind)
            myresponse = imth.get_response(e_id, e_level, e_name, e_managers)
            data.append(myresponse[0].get(s.last3monthnames[0])) #m1
            data.append(myresponse[1].get(s.last3monthnames[1])) #m2
            data.append(myresponse[2].get(s.last3monthnames[2])) #m3

            #ytd data (ind)
            myresponse = iytd.get_response(e_id, e_level, e_name, e_managers) #ytd
            data.append(myresponse)

            #ec
            myec = c.get_response(e_id, e_level, e_name, e_managers) #collegues
            data.append(myec)

            #monthly data (org)
            myresponse = m.get_response(e_id, e_level, e_name, e_managers)
            data.append(myresponse[0].get(s.last3monthnames[0])) #m1
            data.append(myresponse[1].get(s.last3monthnames[1])) #m2
            data.append(myresponse[2].get(s.last3monthnames[2])) #m3

            #ytd data (org)
            ytd_data = y.get_response(e_id, e_level, e_name, e_managers) #ytd
            data.append(ytd_data)

            #past3m data
            myresponse = p.get_response(e_id, e_level, e_name, e_managers)#past 3 months
            data.append(myresponse[0])
            data.append(myresponse[1])
            data.append(myresponse[2])


            #inoffice presence last month (temp)
            #lmpresence = lm.get_response(e_id, e_level, e_name, e_managers)
            #data.append(lmpresence)


            #print(data)
            write_csv("pbi_data", data)

            #middle ribbon data
            mr_datas = mr.get_response(e_id, e_level, e_name, e_managers)
            #print(mr_datas)
            for mr_data in mr_datas:
                write_csv("pbi_mr_data", mr_data)


            #ind details
            ind_details = idet.get_response(e_id, e_level, e_name, e_managers)
            for ind_detail in ind_details:
                write_csv("pbi_ind_data", ind_detail)

            #org details
            org_details = odet.get_response(e_id, e_level, e_name, e_managers)
            for ind_details in org_details:
                for ind_detail in ind_details:
                    write_csv("pbi_org_data", ind_detail)