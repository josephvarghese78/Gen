import json
import RestAPI as rapi
from jsonpath_ng import jsonpath, parse
import PBIPayloads as pl
source_ref="d1"

def __payload():
  return {
    "version": "1.0.0",
    "queries": [
      {
        "Query": {
          "Commands": [
            {
              "SemanticQueryDataShapeCommand": {
                "Query": {
                  "Version": 2,
                  "From": [
                    {
                      "Name": "d",
                      "Entity": "dim_date",
                      "Type": 0
                    },
                    {
                      "Name": "c",
                      "Entity": "Calculations_InView",
                      "Type": 0
                    },
                    {
                      "Name": "c1",
                      "Entity": "Calculations",
                      "Type": 0
                    },
                    {
                      "Name": "d1",
                      "Entity": "dim_ml_pivot",
                      "Type": 0
                    }
                  ],
                  "Select": [
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d"
                          }
                        },
                        "Property": "Year"
                      },
                      "Name": "dim_date.Year",
                      "NativeReferenceName": "Year"
                    },
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "New-Inview-Export-Table_Level1"
                      },
                      "Name": "Calculations_InView.New-Inview-Export-Table_Level1",
                      "NativeReferenceName": "In Office YTD %"
                    }
                  ],
                  "Where": [
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Column": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "d"
                                }
                              },
                              "Property": "FilterAvailableMonthsInYear"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      }
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c"
                                }
                              },
                              "Property": "IND_VISUAL_FILTER"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                            },
                            "Property": "Year"
                          }
                        }
                      ]
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c1"
                                }
                              },
                              "Property": "MULTIPLESELECTION_FILTER"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                            },
                            "Property": "Year"
                          }
                        }
                      ]
                    }
                  ],
                  "OrderBy": [
                    {
                      "Direction": 2,
                      "Expression": {
                        "Measure": {
                          "Expression": {
                            "SourceRef": {
                              "Source": "c"
                            }
                          },
                          "Property": "New-Inview-Export-Table_Level1"
                        }
                      }
                    }
                  ]
                },
                "Binding": {
                  "Primary": {
                    "Groupings": [
                      {
                        "Projections": [
                          0,
                          1
                        ]
                      }
                    ]
                  },
                  "DataReduction": {
                    "DataVolume": 4,
                    "Primary": {
                      "Window": {
                        "Count": 1000
                      }
                    }
                  },
                  "Version": 1
                },
                "ExecutionMetricsKind": 1
              }
            }
          ]
        },
        "QueryId": "34144434-68df-430e-802c-b6aa8b70f365",
        "ApplicationContext": {
          "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
          "Sources": [
            {
              "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
              "VisualId": "7c92ed5cc073e0dd3007",
              "HostProperties": {
                "ConsumptionMethod": "Power BI Web App",
                "UserSession": "870c1ad3-4849-4c8c-aba1-7d7c88f1df8c"
              }
            }
          ]
        }
      }
    ],
    "cancelQueries": [],
    "modelId": 1525791,
    "userPreferredLocale": "en-US",
    "allowLongRunningQueries": True
  }



def get_response(id, level, name, managers):
    global source_ref
    ret=[]
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))

    #print(resp)
    try:
        #ytd_data=resp.get("results")[0].get("result").get("data").get("dsr").get("DS")[0].get("PH")[0].get("DM0")[0].get("C")[1]
        json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0[0].C[1]")
        ytd_data = [match.value for match in json_expr.find(resp)][0]
    except:
        ytd_data="NULL"

    return ytd_data
