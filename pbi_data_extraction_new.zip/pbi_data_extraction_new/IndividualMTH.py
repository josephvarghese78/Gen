import json
from jsonpath_ng import jsonpath, parse
import RestAPI as rapi
import Settings as s
import PBIPayloads as pl
source_ref="d1"
def __payload():
    return {
      "version": "1.0.0",
      "queries": [
        {
          "Query": {
            "Commands": [
              {
                "SemanticQueryDataShapeCommand": {
                  "Query": {
                    "Version": 2,
                    "From": [
                      {
                        "Name": "d",
                        "Entity": "dim_date",
                        "Type": 0
                      },
                      {
                        "Name": "c",
                        "Entity": "Calculations_InView",
                        "Type": 0
                      },
                      {
                        "Name": "c1",
                        "Entity": "Calculations",
                        "Type": 0
                      },
                      {
                        "Name": "d1",
                        "Entity": "dim_ml_pivot",
                        "Type": 0
                      }
                    ],
                    "Select": [
                      {
                        "Column": {
                          "Expression": {
                            "SourceRef": {
                              "Source": "d"
                            }
                          },
                          "Property": "xaxis"
                        },
                        "Name": "dim_date.xaxis",
                        "NativeReferenceName": "xaxis"
                      },
                      {
                        "Measure": {
                          "Expression": {
                            "SourceRef": {
                              "Source": "c"
                            }
                          },
                          "Property": "New-Inview-Export-Table_Level1"
                        },
                        "Name": "Calculations_InView.New-Inview-Export-Table_Level1",
                        "NativeReferenceName": "In Office Monthly %"
                      }
                    ],
                    "Where": [
                      {
                        "Condition": {
                          "Comparison": {
                            "ComparisonKind": 0,
                            "Left": {
                              "Column": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "d"
                                  }
                                },
                                "Property": "Filter3Months"
                              }
                            },
                            "Right": {
                              "Literal": {
                                "Value": "1L"
                              }
                            }
                          }
                        }
                      },
                      {
                        "Condition": {
                          "Comparison": {
                            "ComparisonKind": 0,
                            "Left": {
                              "Measure": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "c"
                                  }
                                },
                                "Property": "IND_VISUAL_FILTER"
                              }
                            },
                            "Right": {
                              "Literal": {
                                "Value": "1L"
                              }
                            }
                          }
                        },
                        "Target": [
                          {
                            "Column": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "d"
                                }
                              },
                              "Property": "xaxis"
                            }
                          }
                        ]
                      },
                      {
                        "Condition": {
                          "Comparison": {
                            "ComparisonKind": 0,
                            "Left": {
                              "Measure": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "c1"
                                  }
                                },
                                "Property": "MULTIPLESELECTION_FILTER"
                              }
                            },
                            "Right": {
                              "Literal": {
                                "Value": "1L"
                              }
                            }
                          }
                        },
                        "Target": [
                          {
                            "Column": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "d"
                                }
                              },
                              "Property": "xaxis"
                            }
                          }
                        ]
                      }
                    ],
                    "OrderBy": [
                      {
                        "Direction": 1,
                        "Expression": {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                            },
                            "Property": "xaxis"
                          }
                        }
                      }
                    ]
                  },
                  "Binding": {
                    "Primary": {
                      "Groupings": [
                        {
                          "Projections": [
                            0,
                            1
                          ]
                        }
                      ]
                    },
                    "DataReduction": {
                      "DataVolume": 4,
                      "Primary": {
                        "Window": {
                          "Count": 1000
                        }
                      }
                    },
                    "Version": 1
                  },
                  "ExecutionMetricsKind": 1
                }
              }
            ]
          },
          "QueryId": "4d96b519-c98d-9959-b44b-55b54704d44d",
          "ApplicationContext": {
            "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
            "Sources": [
              {
                "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
                "VisualId": "1676ace99067c3e6d466",
                "HostProperties": {
                  "ConsumptionMethod": "Power BI Web App",
                  "UserSession": "7bb08320-dd8a-41ee-b24c-13c3172d99dc"
                }
              }
            ]
          }
        }
      ],
      "cancelQueries": [],
      "modelId": 1525791,
      "userPreferredLocale": "en-US",
      "allowLongRunningQueries": True
    }

def get_response(id, level, name, managers):
    global source_ref
    ret=[]
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))


    try:
        json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0")
        monthly_data = [match.value for match in json_expr.find(resp)][0]
    except:
        monthly_data=[]

    try:
        json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D0")
        month_names = [match.value for match in json_expr.find(resp)][0]
    except:
        month_names=[]

    try:
        month_names[0] = month_names[0][:3]
    except:
        month_names.append("NULL")

    try:
        month_names[1] = month_names[1][:3]
    except:
        month_names.append("NULL")

    try:
        month_names[2] = month_names[2][:3]
    except:
        month_names.append("NULL")

    m_name=None
    m_val=None
    #m1
    try:
        data=monthly_data[0]
        if len(data.get("C"))==2:
            m_name = month_names[data.get("C")[0]]
            m_val = str(data.get("C")[1])
        elif len(data.get("C")) == 1:
            m_name = month_names[data.get("C")[0]]
            m_val="NULL"
        else:
            m_name = month_names[0]
            m_val="NOT-FOUND"

        ret.append({m_name: m_val})
    except:
        m_name = month_names[0]
        ret.append({m_name: "NOT-FOUND"})

    #m2
    try:
        data=monthly_data[1]

        if len(data.get("C"))==2:
            m_name = month_names[data.get("C")[0]]
            m_val = str(data.get("C")[1])
        elif len(data.get("C")) == 1:
            m_name = month_names[data.get("C")[0]]
        else:
            m_name = month_names[0]
            m_val="NOT-FOUND"

        ret.append({m_name: m_val})
    except:
        m_name = month_names[1]
        ret.append({m_name: "NOT-FOUND"})

    #m3
    try:
        data=monthly_data[2]
        if len(data.get("C"))==2:
            m_name = month_names[data.get("C")[0]]
            m_val = str(data.get("C")[1])
        elif len(data.get("C")) == 1:
            m_name = month_names[data.get("C")[0]]
        else:
            m_name = month_names[0]
            m_val="NOT-FOUND"

        ret.append({m_name: m_val})
    except:
        m_name = month_names[2]
        ret.append({m_name: "NOT-FOUND"})

    tmpvar = []
    if "NULL" in month_names:
        for mname in s.last3monthnames:
            tmpvar.append({mname: s.find_obj(ret, mname)[mname]})
        ret=tmpvar

    return ret
