import json
from jsonpath_ng import jsonpath, parse
import RestAPI as rapi
import PBIPayloads as pl
source_ref="d"
def __payload():
  return {
    "version": "1.0.0",
    "queries": [
      {
        "Query": {
          "Commands": [
            {
              "SemanticQueryDataShapeCommand": {
                "Query": {
                  "Version": 2,
                  "From": [
                    {
                      "Name": "d",
                      "Entity": "dim_ml_pivot",
                      "Type": 0
                    },
                    {
                      "Name": "d1",
                      "Entity": "dim_date",
                      "Type": 0
                    },
                    {
                      "Name": "d2",
                      "Entity": "daily_attendance",
                      "Type": 0
                    },
                    {
                      "Name": "c",
                      "Entity": "Calculations",
                      "Type": 0
                    },
                    {
                      "Name": "c1",
                      "Entity": "Calculations_InView",
                      "Type": 0
                    }
                  ],
                  "Select": [
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d"
                          }
                        },
                        "Property": "Preferred_Name_UPDW"
                      },
                      "Name": "dim_ml_pivot.Preferred_Name_UPDW",
                      "NativeReferenceName": "Direct Report"
                    },
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d1"
                          }
                        },
                        "Property": "DateWeek"
                      },
                      "Name": "dim_date.DateWeek",
                      "NativeReferenceName": "DateWeek"
                    },
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d1"
                          }
                        },
                        "Property": "xaxis"
                      },
                      "Name": "dim_date.xaxis",
                      "NativeReferenceName": " "
                    },
                    {
                      "Aggregation": {
                        "Expression": {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d2"
                              }
                            },
                            "Property": "record_tag"
                          }
                        },
                        "Function": 3
                      },
                      "Name": "Min(daily_attendance.record_tag)",
                      "NativeReferenceName": "    "
                    }
                  ],
                  "Where": [
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c"
                                }
                              },
                              "Property": "_GetManagerOrIC"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                            },
                            "Property": "Preferred_Name_UPDW"
                          }
                        }
                      ]
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Column": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "d1"
                                }
                              },
                              "Property": "FilterAvailableMonthsInYear"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      }
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c"
                                }
                              },
                              "Property": "MULTIPLESELECTION_FILTER"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                            },
                            "Property": "Preferred_Name_UPDW"
                          }
                        }
                      ]
                    },
                    {
                      "Condition": {
                        "Not": {
                          "Expression": {
                            "In": {
                              "Expressions": [
                                {
                                  "Column": {
                                    "Expression": {
                                      "SourceRef": {
                                        "Source": "d1"
                                      }
                                    },
                                    "Property": "DayName"
                                  }
                                }
                              ],
                              "Values": [
                                [
                                  {
                                    "Literal": {
                                      "Value": "'Saturday'"
                                    }
                                  }
                                ],
                                [
                                  {
                                    "Literal": {
                                      "Value": "'Sunday'"
                                    }
                                  }
                                ]
                              ]
                            }
                          }
                        }
                      }
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c1"
                                }
                              },
                              "Property": "No_Selected_Slicer_Filter"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                              },
                              "Property": "Preferred_Name_UPDW"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  "Binding": {
                    "Primary": {
                      "Groupings": [
                        {
                          "Projections": [
                            0
                          ]
                        }
                      ]
                    },
                    "Secondary": {
                      "Groupings": [
                        {
                          "Projections": [
                            2
                          ]
                        },
                        {
                          "Projections": [
                            1,
                            3
                          ]
                        }
                      ]
                    },
                    "DataReduction": {
                      "DataVolume": 3,
                      "Primary": {
                        "Window": {
                          "Count": 100
                        }
                      },
                      "Secondary": {
                        "Top": {
                          "Count": 100
                        }
                      }
                    },
                    "Version": 1
                  },
                  "ExecutionMetricsKind": 1
                }
              }
            ]
          },
          "QueryId": "9b16f3ed-cb74-6340-14c2-a97f6165276f",
          "ApplicationContext": {
            "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
            "Sources": [
              {
                "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
                "VisualId": "105a67750dc01d6cd055",
                "HostProperties": {
                  "ConsumptionMethod": "Power BI Web App",
                  "UserSession": "660d59ea-c0fa-42de-b0fc-747e6b3e50a3"
                }
              }
            ]
          }
        }
      ],
      "cancelQueries": [],
      "modelId": 1525791,
      "userPreferredLocale": "en-US",
      "allowLongRunningQueries": True
    }

def get_response(id, level, name, managers):
    global source_ref
    ret=[]
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))

    #name
    json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0[*].G0")
    ind_names = [match.value for match in json_expr.find(resp)]

    if len(ind_names)>0 :

        #month list
        json_expr = parse("$.results[0].result.data.dsr.DS[0].SH[0].DM1[*]")
        months = [match.value for match in json_expr.find(resp)]

        #days list
        json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D0")
        days = [match.value for match in json_expr.find(resp)][0]

        #legend list
        json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D1")
        legend = [match.value for match in json_expr.find(resp)][0]

        #org data
        json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0")
        org_month_data = [match.value for match in json_expr.find(resp)][0]

        #make caladander
        ind_org_data = []
        for ind_name in ind_names:
            data_list = []
            for month in months:
                month_name = month.get("G1")[:3]
                json_expr = parse("$.M[*].DM2[*].G2")
                data = [match.value for match in json_expr.find(month)]
                for d in data:
                    data_list.append([id, name, ind_name, month_name, days[d].split("\n")[0], days[d].split("\n")[1], "X"])
            ind_org_data.append(data_list)

        for i in range(len(org_month_data)):
            ind_datas = org_month_data[i].get("X")
            start_index = None
            for ind_data in ind_datas:
                #if start_index is None:
                #    start_index = ind_data.get("I")
                #    if start_index is None:
                #        start_index = 0

                if ind_data.get("I") is not None:
                    start_index = ind_data.get("I")
                else:
                    if start_index is None:
                        start_index=0

                if ind_data.get("R") is None:
                    val = ind_data.get("M0")

                if val is not None:
                    if str(legend[val]) == "Y" or str(legend[val]) == "N":
                        ind_mth_data = legend[val]
                    else:
                        ind_mth_data = "BT"

                    ind_org_data[i][start_index][6] = str(ind_mth_data)
                    start_index += 1
                else:
                    start_index = None


        return ind_org_data
    else:
        return [[[id, name, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL']]]

