import json
from jsonpath_ng import jsonpath, parse
manager_levels=['01','02','03','04','05','06','07', '08','09','10']

def __getpbicondition(source, level, name):
  return {
      "Condition": {
          "In": {
              "Expressions": [
                  {
                      "Column": {
                          "Expression": {
                              "SourceRef": {
                                  "Source": source
                              }
                          },
                          "Property": level
                      }
                  }
              ],
              "Values": [
                  [
                      {
                          "Literal": {
                              "Value": f"'{name}'"
                          }
                      }
                  ]
              ]
          }
      }
  }

def getpbipayload(payload, source, level, name, managers):
    l=0
    conditions = []
    for manager in managers:
      if len(manager.strip())>0:
        condition=__getpbicondition(source,f"Manager_Level_{manager_levels[l]}", str(manager).replace("'", "''"))
        conditions.append(condition)
        l+=1
      else:
        break

    condition = __getpbicondition(source,level, str(name).replace("'", "''"))
    conditions.append(condition)
    
    where_c=payload["queries"][0]["Query"]["Commands"][0]["SemanticQueryDataShapeCommand"]["Query"]["Where"]
    where_c+=conditions
    payload["queries"][0]["Query"]["Commands"][0]["SemanticQueryDataShapeCommand"]["Query"]["Where"]=where_c
    #print(json.dumps(payload))
    return payload