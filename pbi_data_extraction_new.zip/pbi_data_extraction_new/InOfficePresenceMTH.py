import json
from jsonpath_ng import jsonpath, parse
import RestAPI as rapi
import Settings as s
import PBIPayloads as pl
source_ref="d1"
def __payload():
    return {
      "version": "1.0.0",
      "queries": [
        {
          "Query": {
            "Commands": [
              {
                "SemanticQueryDataShapeCommand": {
                  "Query": {
                    "Version": 2,
                    "From": [
                      {
                        "Name": "c",
                        "Entity": "Calculations",
                        "Type": 0
                      },
                      {
                        "Name": "d",
                        "Entity": "dim_date",
                        "Type": 0
                      },
                      {
                        "Name": "d1",
                        "Entity": "dim_ml_pivot",
                        "Type": 0
                      }
                    ],
                    "Select": [
                      {
                        "Column": {
                          "Expression": {
                            "SourceRef": {
                              "Source": "d"
                            }
                          },
                          "Property": "xaxis"
                        },
                        "Name": "dim_date.xaxis",
                        "NativeReferenceName": "Month"
                      },
                      {
                        "Measure": {
                          "Expression": {
                            "SourceRef": {
                              "Source": "c"
                            }
                          },
                          "Property": "Level1_inOfficeMnth%"
                        },
                        "Name": "Calculations.Level1_inOfficeMnth%",
                        "NativeReferenceName": "In Office Monthly %"
                      }
                    ],
                    "Where": [
                      {
                        "Condition": {
                          "Comparison": {
                            "ComparisonKind": 0,
                            "Left": {
                              "Measure": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "c"
                                  }
                                },
                                "Property": "MULTIPLESELECTION_FILTER"
                              }
                            },
                            "Right": {
                              "Literal": {
                                "Value": "1L"
                              }
                            }
                          }
                        },
                        "Target": [
                          {
                            "Column": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "d"
                                }
                              },
                              "Property": "xaxis"
                            }
                          }
                        ]
                      },
                      {
                        "Condition": {
                          "Comparison": {
                            "ComparisonKind": 0,
                            "Left": {
                              "Measure": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "c"
                                  }
                                },
                                "Property": "_GetManagerOrIC"
                              }
                            },
                            "Right": {
                              "Literal": {
                                "Value": "1L"
                              }
                            }
                          }
                        },
                        "Target": [
                          {
                            "Column": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "d"
                                }
                              },
                              "Property": "xaxis"
                            }
                          }
                        ]
                      },
                      {
                        "Condition": {
                          "Comparison": {
                            "ComparisonKind": 0,
                            "Left": {
                              "Column": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "d"
                                  }
                                },
                                "Property": "Filter3Months"
                              }
                            },
                            "Right": {
                              "Literal": {
                                "Value": "1L"
                              }
                            }
                          }
                        }
                      }
                    ],
                    "OrderBy": [
                      {
                        "Direction": 1,
                        "Expression": {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                            },
                            "Property": "xaxis"
                          }
                        }
                      }
                    ]
                  },
                  "Binding": {
                    "Primary": {
                      "Groupings": [
                        {
                          "Projections": [
                            0,
                            1
                          ]
                        }
                      ]
                    },
                    "DataReduction": {
                      "DataVolume": 4,
                      "Primary": {
                        "Window": {
                          "Count": 1000
                        }
                      }
                    },
                    "Version": 1
                  },
                  "ExecutionMetricsKind": 1
                }
              }
            ]
          },
          "QueryId": "c2989a11-d8f8-10bb-ccf0-bb698905a701",
          "ApplicationContext": {
            "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
            "Sources": [
              {
                "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
                "VisualId": "edbbe176e87a02618c00",
                "HostProperties": {
                  "ConsumptionMethod": "Power BI Web App",
                  "UserSession": "660d59ea-c0fa-42de-b0fc-747e6b3e50a3"
                }
              }
            ]
          }
        }
      ],
      "cancelQueries": [],
      "modelId": 1525791,
      "userPreferredLocale": "en-US",
      "allowLongRunningQueries": True
    }

def get_response(id, level, name, managers):
    global source_ref
    ret=[]
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))
    
    try:
        json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0")
        monthly_data = [match.value for match in json_expr.find(resp)][0]
    except:
        monthly_data=[]

    try:
        json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D0")
        month_names = [match.value for match in json_expr.find(resp)][0]
    except:
        month_names=[]

    try:
        month_names[0] = month_names[0][:3]
    except:
        month_names.append("NULL")

    try:
        month_names[1] = month_names[1][:3]
    except:
        month_names.append("NULL")

    try:
        month_names[2] = month_names[2][:3]
    except:
        month_names.append("NULL")


    #m1
    lastval=None
    c_val=None
    try:
        data=monthly_data[0]
        try:
            c_val=data.get("C")
            if len(c_val)==1:
                if "R" not in data:
                    lastval="NULL"
            elif len(c_val)>=2:
                lastval = str(data.get("C")[1])

            ret.append({month_names[data.get("C")[0]]: lastval})
        except:
            ret.append({month_names[data.get("C")[0]]: "NULL"})
    except:
        ret.append({month_names[0]: "NOT-FOUND"})

    #m2
    try:
        data=monthly_data[1]
        try:
            c_val=data.get("C")
            if len(c_val)==1:
                if "R" not in data:
                    lastval="NULL"
            elif len(c_val)>=2:
                lastval = str(data.get("C")[1])

            ret.append({month_names[data.get("C")[0]]: lastval})
        except:
            ret.append({month_names[data.get("C")[0]]: "NULL"})
    except:
        ret.append({month_names[1]: "NOT-FOUND"})

    #m3
    try:
        data=monthly_data[2]
        try:
            c_val=data.get("C")
            if len(c_val)==1:
                if "R" not in data:
                    lastval="NULL"
            elif len(c_val)>=2:
                lastval = str(data.get("C")[1])

            ret.append({month_names[data.get("C")[0]]: lastval})
        except:
            ret.append({month_names[data.get("C")[0]]: "NULL"})
    except:
        ret.append({month_names[2]: "NOT-FOUND"})

    tmpvar = []
    if "NULL" in month_names:
        for mname in s.last3monthnames:
            tmpvar.append({mname: s.find_obj(ret, mname)[mname]})
        ret=tmpvar

    return ret
