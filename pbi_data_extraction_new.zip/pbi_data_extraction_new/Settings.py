api_url =""
pbi_url =""
mwc_token =""
br_token=""
header ={}
ignoressl = False
timeout = 10000
calandermonths=["Jan","Feb","Mar", "Apr","May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
last3monthnames=["Jul", "Aug", "Sep"]

def find_obj(lst, key):
    for obj in lst:
        if key in obj:
            return obj
    else:
        return {key: "NULL"}