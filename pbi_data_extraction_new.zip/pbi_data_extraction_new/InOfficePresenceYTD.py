import json
import RestAPI as rapi
from jsonpath_ng import jsonpath, parse
import PBIPayloads as pl
source_ref="d1"
def __payload():
  return {
    "version": "1.0.0",
    "queries": [
      {
        "Query": {
          "Commands": [
            {
              "SemanticQueryDataShapeCommand": {
                "Query": {
                  "Version": 2,
                  "From": [
                    {
                      "Name": "c",
                      "Entity": "Calculations",
                      "Type": 0
                    },
                    {
                      "Name": "d",
                      "Entity": "dim_date",
                      "Type": 0
                    },
                    {
                      "Name": "d1",
                      "Entity": "dim_ml_pivot",
                      "Type": 0
                    }
                  ],
                  "Select": [
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d"
                          }
                        },
                        "Property": "Year"
                      },
                      "Name": "dim_date.Year",
                      "NativeReferenceName": "Year"
                    },
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "Level1_inOfficeYTD%"
                      },
                      "Name": "Calculations.Level1_inOfficeYTD%",
                      "NativeReferenceName": "In Office YTD %"
                    }
                  ],
                  "Where": [
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c"
                                }
                              },
                              "Property": "MULTIPLESELECTION_FILTER"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                            },
                            "Property": "Year"
                          }
                        }
                      ]
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c"
                                }
                              },
                              "Property": "_GetManagerOrIC"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d"
                              }
                            },
                            "Property": "Year"
                          }
                        }
                      ]
                    },
                    {
                      "Condition": {
                        "In": {
                          "Expressions": [
                            {
                              "Column": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "d"
                                  }
                                },
                                "Property": "FilterAvailableMonthsInYear"
                              }
                            }
                          ],
                          "Values": [
                            [
                              {
                                "Literal": {
                                  "Value": "1L"
                                }
                              }
                            ]
                          ]
                        }
                      }
                    }
                  ],
                  "OrderBy": [
                    {
                      "Direction": 2,
                      "Expression": {
                        "Measure": {
                          "Expression": {
                            "SourceRef": {
                              "Source": "c"
                            }
                          },
                          "Property": "Level1_inOfficeYTD%"
                        }
                      }
                    }
                  ]
                },
                "Binding": {
                  "Primary": {
                    "Groupings": [
                      {
                        "Projections": [
                          0,
                          1
                        ]
                      }
                    ]
                  },
                  "DataReduction": {
                    "DataVolume": 4,
                    "Primary": {
                      "Window": {
                        "Count": 1000
                      }
                    }
                  },
                  "Version": 1
                },
                "ExecutionMetricsKind": 1
              }
            }
          ]
        },
        "QueryId": "9e663e7d-dbbc-7955-d101-35f406be8ac7",
        "ApplicationContext": {
          "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
          "Sources": [
            {
              "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
              "VisualId": "629695f739bd421e09b0",
              "HostProperties": {
                "ConsumptionMethod": "Power BI Web App",
                "UserSession": "660d59ea-c0fa-42de-b0fc-747e6b3e50a3"
              }
            }
          ]
        }
      }
    ],
    "cancelQueries": [],
    "modelId": 1525791,
    "userPreferredLocale": "en-US",
    "allowLongRunningQueries": True
  }



def get_response(id, level, name, managers):
    global source_ref
    ret=[]
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))


    #print(resp)
    try:
        #ytd_data=resp.get("results")[0].get("result").get("data").get("dsr").get("DS")[0].get("PH")[0].get("DM0")[0].get("C")[1]
        json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0[0].C[1]")
        ytd_data = [match.value for match in json_expr.find(resp)][0]
    except:
        ytd_data="NULL"

    return ytd_data
