import json
import requests
import Settings
import RestAPI as rapi
from jsonpath_ng import jsonpath, parse
import PBIPayloads as pl
source_ref="d1"
def __payload():
  return {
    "version": "1.0.0",
    "queries": [
      {
        "Query": {
          "Commands": [
            {
              "SemanticQueryDataShapeCommand": {
                "Query": {
                  "Version": 2,
                  "From": [
                    {
                      "Name": "d1",
                      "Entity": "dim_ml_pivot",
                      "Type": 0
                    },
                    {
                      "Name": "c",
                      "Entity": "Calculations",
                      "Type": 0
                    },
                    {
                      "Name": "d",
                      "Entity": "dim_date",
                      "Type": 0
                    }
                  ],
                  "Select": [
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d1"
                          }
                        },
                        "Property": "Preferred_Name_UPDW"
                      },
                      "Name": "dim_ml_pivot.Preferred_Name_UPDW",
                      "NativeReferenceName": " "
                    },
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "_midValue"
                      },
                      "Name": "Calculations._midValue",
                      "NativeReferenceName": " 1"
                    },
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d1"
                          }
                        },
                        "Property": "Employee_ID"
                      },
                      "Name": "dim_ml_pivot.Employee_ID",
                      "NativeReferenceName": " 2"
                    },
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "_MidValue_CC"
                      },
                      "Name": "Calculations._MidValue_CC"
                    }
                  ],
                  "Where": [
                    {
                      "Condition": {
                        "In": {
                          "Expressions": [
                            {
                              "Column": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "d"
                                  }
                                },
                                "Property": "Filter3Months"
                              }
                            }
                          ],
                          "Values": [
                            [
                              {
                                "Literal": {
                                  "Value": "1L"
                                }
                              }
                            ]
                          ]
                        }
                      }
                    },
                    {
                      "Condition": {
                        "In": {
                          "Expressions": [
                            {
                              "Column": {
                                "Expression": {
                                  "SourceRef": {
                                    "Source": "d1"
                                  }
                                },
                                "Property": "FilterMid"
                              }
                            }
                          ],
                          "Values": [
                            [
                              {
                                "Literal": {
                                  "Value": "1L"
                                }
                              }
                            ]
                          ]
                        }
                      }
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c"
                                }
                              },
                              "Property": "MULTIPLESELECTION_FILTER"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d1"
                              }
                            },
                            "Property": "Employee_ID"
                          }
                        },
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d1"
                              }
                            },
                            "Property": "Preferred_Name_UPDW"
                          }
                        }
                      ]
                    }
                  ]
                },
                "Binding": {
                  "Primary": {
                    "Groupings": [
                      {
                        "Projections": [
                          2
                        ]
                      },
                      {
                        "Projections": [
                          0,
                          1,
                          3
                        ]
                      }
                    ]
                  },
                  "DataReduction": {
                    "DataVolume": 3,
                    "Primary": {
                      "Top": {
                        "Count": 100
                      }
                    }
                  },
                  "SuppressedJoinPredicates": [
                    3
                  ],
                  "Version": 1,
                  "isPivoted": True
                },
                "ExecutionMetricsKind": 1
              }
            }
          ]
        },
        "QueryId": "9d4f1954-fadf-b726-7957-8603a5981769",
        "ApplicationContext": {
          "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
          "Sources": [
            {
              "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
              "VisualId": "5f09ddf004cac2bc2000",
              "HostProperties": {
                "ConsumptionMethod": "Power BI Web App",
                "UserSession": "660d59ea-c0fa-42de-b0fc-747e6b3e50a3"
              }
            }
          ]
        }
      }
    ],
    "cancelQueries": [],
    "modelId": 1525791,
    "userPreferredLocale": "en-US",
    "allowLongRunningQueries": True
  }

def get_response(id, level, name, managers):
    global source_ref
    ret=[]
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))

    #direct report names
    json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D0")
    try:
        dr_names = [match.value for match in json_expr.find(resp)][0]
    except:
        dr_names=[]

    if len(dr_names)>0:
        #direct report data
        json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D1")
        dr_data = [match.value for match in json_expr.find(resp)][0]

        #direct report colorcode
        json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D2")
        dr_colorcode = [match.value for match in json_expr.find(resp)][0]

        #mappings
        json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0")
        mr_mappings = [match.value for match in json_expr.find(resp)][0]

        #re-map
        color_code = ""
        for mr_mapping in mr_mappings:
            json_expr = parse("$.G0")
            dr_id = [match.value for match in json_expr.find(mr_mapping)][0]

            mr_data = []
            mr_data.append(id)
            mr_data.append(name)
            mr_data.append(dr_id)

            json_expr = parse("$.M[0].DM1[0].C")
            dr_map = [match.value for match in json_expr.find(mr_mapping)][0]


            try:
                dr_data_name=dr_names[dr_map[0]]
            except:
                pass
            mr_data.append(dr_data_name)

            try:
                dr_data_data=dr_data[dr_map[1]]
            except:
                pass
            mr_data.append(str(dr_data_data).split("\n")[0])

            try:
                mr_data.append(str(dr_data_data).split("\n")[1])
            except:
                mr_data.append("")


            if len(dr_map) == 3:
                if dr_colorcode[dr_map[2]] == "#EC6453":
                    color_code = "Red"
                elif dr_colorcode[dr_map[2]] == "#F9AB2E":
                    color_code = "Orange"
                else:
                    color_code = "Green"

            mr_data.append(color_code)
            ret.append(mr_data)
        return ret
    else:
        return [[id, name, 'NULL','NULL','NULL','NULL','NULL']]
