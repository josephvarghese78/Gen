import json
from jsonpath_ng import jsonpath, parse
import RestAPI as rapi
import PBIPayloads as pl
source_ref="d"
def __payload():
  return  {
    "version": "1.0.0",
    "queries": [
      {
        "Query": {
          "Commands": [
            {
              "SemanticQueryDataShapeCommand": {
                "Query": {
                  "Version": 2,
                  "From": [
                    {
                      "Name": "c",
                      "Entity": "Calculations",
                      "Type": 0
                    },
                    {
                      "Name": "d",
                      "Entity": "dim_ml_pivot",
                      "Type": 0
                    }
                  ],
                  "Select": [
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "_Total_Employees"
                      },
                      "Name": "Calculations._Total_Employees",
                      "NativeReferenceName": "Total Eligible Colleagues"
                    }
                  ],
                  "Where": [

                  ]
                },
                "Binding": {
                  "Primary": {
                    "Groupings": [
                      {
                        "Projections": [
                          0
                        ]
                      }
                    ]
                  },
                  "DataReduction": {
                    "DataVolume": 3,
                    "Primary": {
                      "Top": {}
                    }
                  },
                  "Version": 1
                },
                "ExecutionMetricsKind": 1
              }
            }
          ]
        },
        "QueryId": "817bfd6f-af51-3318-c65d-3abb23d57db4",
        "ApplicationContext": {
          "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
          "Sources": [
            {
              "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
              "VisualId": "70c4211a76d15c900e17",
              "HostProperties": {
                "ConsumptionMethod": "Power BI Web App",
                "UserSession": "660d59ea-c0fa-42de-b0fc-747e6b3e50a3"
              }
            }
          ]
        }
      }
    ],
    "cancelQueries": [],
    "modelId": 1525791,
    "userPreferredLocale": "en-US",
    "allowLongRunningQueries": True
  }



def get_response(id, level, name, managers):
    global source_ref
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))

    try:
        #colleagues_data=resp.get("results")[0].get("result").get("data").get("dsr").get("DS")[0].get("PH")[0].get("DM0")[0].get("M0")
        json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0[0].M0")
        colleagues_data = [match.value for match in json_expr.find(resp)][0]
    except:
        colleagues_data="NULL"

    return colleagues_data

