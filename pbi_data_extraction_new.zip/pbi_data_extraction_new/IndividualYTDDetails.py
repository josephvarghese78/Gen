import json
from jsonpath_ng import jsonpath, parse
import RestAPI as rapi
import PBIPayloads as pl
source_ref="d11"
def __payload():
  return {
    "version": "1.0.0",
    "queries": [
      {
        "Query": {
          "Commands": [
            {
              "SemanticQueryDataShapeCommand": {
                "Query": {
                  "Version": 2,
                  "From": [
                    {
                      "Name": "d",
                      "Entity": "dim_date",
                      "Type": 0
                    },
                    {
                      "Name": "c",
                      "Entity": "Calculations_InView",
                      "Type": 0
                    },
                    {
                      "Name": "d1",
                      "Entity": "daily_attendance",
                      "Type": 0
                    },
                    {
                      "Name": "c1",
                      "Entity": "Calculations",
                      "Type": 0
                    },
                    {
                      "Name": "d11",
                      "Entity": "dim_ml_pivot",
                      "Type": 0
                    }
                  ],
                  "Select": [
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d"
                          }
                        },
                        "Property": "DateWeek"
                      },
                      "Name": "dim_date.DateWeek",
                      "NativeReferenceName": "Date"
                    },
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d"
                          }
                        },
                        "Property": "xaxis"
                      },
                      "Name": "dim_date.xaxis",
                      "NativeReferenceName": " "
                    },
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "_In-OfficeY/N_checker_new"
                      },
                      "Name": "Calculations_InView._In-OfficeY/N_checker_new",
                      "NativeReferenceName": "In Office1"
                    },
                    {
                      "Column": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "d1"
                          }
                        },
                        "Property": "Preferred_Name_UPDW"
                      },
                      "Name": "daily_attendance.Preferred_Name_UPDW",
                      "NativeReferenceName": "Name"
                    }
                  ],
                  "Where": [
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Column": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "d"
                                }
                              },
                              "Property": "FilterAvailableMonthsInYear"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      }
                    },
                    {
                      "Condition": {
                        "Not": {
                          "Expression": {
                            "In": {
                              "Expressions": [
                                {
                                  "Column": {
                                    "Expression": {
                                      "SourceRef": {
                                        "Source": "d"
                                      }
                                    },
                                    "Property": "DayName"
                                  }
                                }
                              ],
                              "Values": [
                                [
                                  {
                                    "Literal": {
                                      "Value": "'Saturday'"
                                    }
                                  }
                                ],
                                [
                                  {
                                    "Literal": {
                                      "Value": "'Sunday'"
                                    }
                                  }
                                ]
                              ]
                            }
                          }
                        }
                      }
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c"
                                }
                              },
                              "Property": "IND_VISUAL_FILTER"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d1"
                              }
                            },
                            "Property": "Preferred_Name_UPDW"
                          }
                        }
                      ]
                    },
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Measure": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "c1"
                                }
                              },
                              "Property": "MULTIPLESELECTION_FILTER"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      },
                      "Target": [
                        {
                          "Column": {
                            "Expression": {
                              "SourceRef": {
                                "Source": "d1"
                              }
                            },
                            "Property": "Preferred_Name_UPDW"
                          }
                        }
                      ]
                    }
                  ]
                },
                "Binding": {
                  "Primary": {
                    "Groupings": [
                      {
                        "Projections": [
                          3
                        ]
                      }
                    ]
                  },
                  "Secondary": {
                    "Groupings": [
                      {
                        "Projections": [
                          1
                        ]
                      },
                      {
                        "Projections": [
                          0,
                          2
                        ]
                      }
                    ]
                  },
                  "DataReduction": {
                    "DataVolume": 3,
                    "Primary": {
                      "Window": {
                        "Count": 100
                      }
                    },
                    "Secondary": {
                      "Top": {
                        "Count": 100
                      }
                    }
                  },
                  "Version": 1
                },
                "ExecutionMetricsKind": 1
              }
            }
          ]
        },
        "QueryId": "12458827-772d-3e46-f2be-d9ecb00aea30",
        "ApplicationContext": {
          "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
          "Sources": [
            {
              "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
              "VisualId": "41ed35f313e7d0a2818e",
              "HostProperties": {
                "ConsumptionMethod": "Power BI Web App",
                "UserSession": "870c1ad3-4849-4c8c-aba1-7d7c88f1df8c"
              }
            }
          ]
        }
      }
    ],
    "cancelQueries": [],
    "modelId": 1525791,
    "userPreferredLocale": "en-US",
    "allowLongRunningQueries": True
  }

def get_response(id, level, name, managers):
    global source_ref
    ret=[]
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))

    # name
    json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0[0].G0")
    ind_name = [match.value for match in json_expr.find(resp)]
    if len(ind_name)>0:
        ind_name=ind_name[0]

        #month list
        json_expr = parse("$.results[0].result.data.dsr.DS[0].SH[0].DM1[*]")
        months = [match.value for match in json_expr.find(resp)]

        #days list
        json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D0")
        days = [match.value for match in json_expr.find(resp)][0]

        #make caladander
        month_list=[]
        for month in months:
            month_name = month.get("G1")[:3]
            json_expr = parse("$.M[*].DM2[*].G2")
            data = [match.value for match in json_expr.find(month)]
            for d in data:
                month_list.append([id, ind_name, month_name, days[d].split("\n")[0], days[d].split("\n")[1]])

        # legend list
        json_expr = parse("$.results[0].result.data.dsr.DS[0].ValueDicts.D1")
        legend = [match.value for match in json_expr.find(resp)][0]

        # individual data
        json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0[0].X")
        ind_month_data = [match.value for match in json_expr.find(resp)][0]

        # final data
        for i in range(len(month_list)):
            ind_data = ind_month_data[i]
            if ind_data.get("R") is None:
                val = ind_data.get("M0")
            if str(legend[val])=="Y" or str(legend[val])=="N":
                ind_mth_data = legend[val]
            else:
                ind_mth_data = "BT"
            month_list[i].append(ind_mth_data)

        return month_list
    else:
        return [[id, name, 'NULL', 'NULL', 'NULL', 'NULL']]

