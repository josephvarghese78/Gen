import json
from jsonpath_ng import jsonpath, parse
import RestAPI as rapi
import PBIPayloads as pl
source_ref="d1"
def __payload():
  return {
    "version": "1.0.0",
    "queries": [
      {
        "Query": {
          "Commands": [
            {
              "SemanticQueryDataShapeCommand": {
                "Query": {
                  "Version": 2,
                  "From": [
                    {
                      "Name": "c",
                      "Entity": "Calculations",
                      "Type": 0
                    },
                    {
                      "Name": "d",
                      "Entity": "dim_date",
                      "Type": 0
                    },
                    {
                      "Name": "d1",
                      "Entity": "dim_ml_pivot",
                      "Type": 0
                    }
                  ],
                  "Select": [
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "_1.4_OrgInOfficeMonthly% (Green)_"
                      },
                      "Name": "Calculations._1.4_OrgInOfficeMonthly% (Green)_",
                      "NativeReferenceName": ">=85%"
                    },
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "_1.4_OrgInOfficeMonthly% (Red)"
                      },
                      "Name": "Calculations._1.4_OrgInOfficeMonthly% (Red)",
                      "NativeReferenceName": "<70%"
                    },
                    {
                      "Measure": {
                        "Expression": {
                          "SourceRef": {
                            "Source": "c"
                          }
                        },
                        "Property": "_1.4_OrgInOfficeMonthly% (Amber)"
                      },
                      "Name": "Calculations._1.4_OrgInOfficeMonthly% (Amber)",
                      "NativeReferenceName": ">=70% <85%"
                    }
                  ],
                  "Where": [
                    {
                      "Condition": {
                        "Comparison": {
                          "ComparisonKind": 0,
                          "Left": {
                            "Column": {
                              "Expression": {
                                "SourceRef": {
                                  "Source": "d"
                                }
                              },
                              "Property": "Filter3Months"
                            }
                          },
                          "Right": {
                            "Literal": {
                              "Value": "1L"
                            }
                          }
                        }
                      }
                    }
                  ],
                  "OrderBy": [
                    {
                      "Direction": 2,
                      "Expression": {
                        "Measure": {
                          "Expression": {
                            "SourceRef": {
                              "Source": "c"
                            }
                          },
                          "Property": "_1.4_OrgInOfficeMonthly% (Green)_"
                        }
                      }
                    }
                  ]
                },
                "Binding": {
                  "Primary": {
                    "Groupings": [
                      {
                        "Projections": [
                          0,
                          1,
                          2
                        ]
                      }
                    ]
                  },
                  "Version": 1
                },
                "ExecutionMetricsKind": 1
              }
            }
          ]
        },
        "QueryId": "1c773b3d-3eac-478c-dde3-c237918305ce",
        "ApplicationContext": {
          "DatasetId": "20196311-ab8c-49d7-a343-bc92296b30d4",
          "Sources": [
            {
              "ReportId": "aa42bd61-3aaa-476c-a9ab-dd53fe23ff79",
              "VisualId": "808f2dd273308dda04c9",
              "HostProperties": {
                "ConsumptionMethod": "Power BI Web App",
                "UserSession": "660d59ea-c0fa-42de-b0fc-747e6b3e50a3"
              }
            }
          ]
        }
      }
    ],
    "cancelQueries": [],
    "modelId": 1525791,
    "userPreferredLocale": "en-US",
    "allowLongRunningQueries": True
  }

def get_response(id, level, name, managers):
    global source_ref
    ret=[]
    resp = rapi.getresponse(pl.getpbipayload(__payload(), source_ref, level, name, managers))
    json_expr = parse("$.results[0].result.data.dsr.DS[0].PH[0].DM0[0].C")

    try:
      p3m_data = [match.value for match in json_expr.find(resp)][0]
    except:
      p3m_data=["NULL", "NULL", "NULL"]

    try:
        ret.append(p3m_data[0])
    except:
        ret.append("NULL")

    try:
        ret.append(p3m_data[1])
    except:
        ret.append("NULL")

    try:
        ret.append(p3m_data[2])
    except:
        ret.append("NULL")

    return ret
